public enum PianoTariffario {

    MINUTI_ILLIMITATI,
    MEGA_GIGA,
    SCATTO_ALLA_RISPOSTA

}
